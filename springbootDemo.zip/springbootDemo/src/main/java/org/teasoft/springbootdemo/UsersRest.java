//package org.teasoft.springbootdemo;
//
//import java.util.List;
//
//import org.abc.gencode.Const;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.RestController;
//import org.teasoft.bee.mvc.Result;
//import org.teasoft.bee.osql.api.SuidRich;
//import org.teasoft.honey.osql.core.Logger;
//import org.teasoft.honey.osql.shortcut.BF;
//
//@RestController
//@RequestMapping("/users")
//public class UsersRest {
//	
//	SuidRich suidRich=BF.getSuidRich();
//
//	@GetMapping("/list")
//	public Result list(Users users,
//	                @RequestParam(value = "page", defaultValue = "1", required = false) int page,
//			        @RequestParam(value = "size", defaultValue = "20", required = false) int size) {
//		Result result = new Result();
//		
//		try {
//			int total = suidRich.count(users);
//			List<Users> list = suidRich.select(users, (page - 1) * size, size);
//			result.setRows(list);
//			result.setTotal(total);
//			result.setMsg(Const.MSG_OK);
//			result.setCode(Const.CODE_OK);
//		} catch (Exception e) {
//			result.setErrorMsg(Const.MSG_ERROR);
//			result.setErrorCode(Const.CODE_ERROR);
//			Logger.error(e.getMessage(), e);
//		}
//
//		return result;
//	}
//	
//	@PostMapping("/add")
//	public Result insert(Users users) {
//
//		Result result = new Result();
//		try {
//			int num = suidRich.insert(users);
//			result.setTotal(num);
//			if (num == 1) {
//				result.setMsg(Const.MSG_OK);
//				result.setCode(Const.CODE_OK);
//			} else if (num == 0) {
//				result.setMsg(Const.CODE_NONE);
//				result.setCode(Const.MSG_NONE);
//			} else if (num < 0) {
//				result.setErrorMsg(Const.MSG_UPDATE_ERROR);
//				result.setErrorCode(Const.CODE_FAILED);
//			}
//		} catch (Exception e) {
//			result.setErrorMsg(Const.MSG_ERROR);
//			result.setErrorCode(Const.CODE_ERROR);
//			Logger.error(e.getMessage(), e);
//		}
//		return result;
//	}
//}
