//package org.teasoft.springbootdemo;
//
//import java.io.Serializable;
//
///**
// * @author Honey
// */
//public class Users implements Serializable {
//
//	private static final long serialVersionUID = 1590027317066L;
//
//	private Long id;
//	private String userid;
//	private String username;
//	private String pw;
//	private String type;
//	private String tel;
//	private String wechat;
//	private String regtime;
//	private String updatetime;
//	private String updater;
//	private String remark;
//	public Long getId() {
//		return id;
//	}
//	public void setId(Long id) {
//		this.id = id;
//	}
//	public String getUserid() {
//		return userid;
//	}
//	public void setUserid(String userid) {
//		this.userid = userid;
//	}
//	public String getUsername() {
//		return username;
//	}
//	public void setUsername(String username) {
//		this.username = username;
//	}
//	public String getPw() {
//		return pw;
//	}
//	public void setPw(String pw) {
//		this.pw = pw;
//	}
//	public String getType() {
//		return type;
//	}
//	public void setType(String type) {
//		this.type = type;
//	}
//	public String getTel() {
//		return tel;
//	}
//	public void setTel(String tel) {
//		this.tel = tel;
//	}
//	public String getWechat() {
//		return wechat;
//	}
//	public void setWechat(String wechat) {
//		this.wechat = wechat;
//	}
//	public String getRegtime() {
//		return regtime;
//	}
//	public void setRegtime(String regtime) {
//		this.regtime = regtime;
//	}
//	public String getUpdatetime() {
//		return updatetime;
//	}
//	public void setUpdatetime(String updatetime) {
//		this.updatetime = updatetime;
//	}
//	public String getUpdater() {
//		return updater;
//	}
//	public void setUpdater(String updater) {
//		this.updater = updater;
//	}
//	public String getRemark() {
//		return remark;
//	}
//	public void setRemark(String remark) {
//		this.remark = remark;
//	}
//
//}